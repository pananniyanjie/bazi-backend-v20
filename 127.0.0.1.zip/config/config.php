<?php

# 在这里配置数据库相关参数，注意都是字符串
# HOST => IP:PORT 
const DB_HOST = "127.0.0.1:3306";
const DB_USER = "bazidbuser";
const DB_PWD = "bazidbuserpwd";
const DB_DBNAME = "bazi";
const API_PWD = "cqmygysdssjtwmydtsgx";

?>